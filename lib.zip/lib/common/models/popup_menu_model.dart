import 'package:demandium/utils/core_export.dart';

class PopupMenuModel{
  final String title;
  final IconData icon;
  PopupMenuModel({required this.title, required this.icon});
}