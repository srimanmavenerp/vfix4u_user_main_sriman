import 'dart:convert';
import 'package:demandium/utils/core_export.dart';
import 'package:get/get.dart';

class PaymentGatewayScreen extends StatelessWidget {
  final String address;
  final bool isPartialPayment;
  final CheckOutController checkoutController;

  const PaymentGatewayScreen({
    super.key,
    required this.address,
    required this.isPartialPayment,
    required this.checkoutController,
    DigitalPaymentMethod? selectedPaymentMethod,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Payment Gateway")),
      body: Padding(
        padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Display the selected payment method
            Obx(() {
              return Text(
                "Payment Method: ${_getSelectedPaymentMethodName()}",
                style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeLarge),
              );
            }),
            const SizedBox(height: Dimensions.paddingSizeLarge),

            // Display available payment methods based on the selected method (digital, offline, wallet)
            _buildPaymentMethodList(),
            const SizedBox(height: Dimensions.paddingSizeLarge),

            // Proceed with selected method button
            ElevatedButton(
              onPressed: () {
                if (checkoutController.selectedPaymentMethod != PaymentMethodName.none) {
                  _proceedWithPayment();
                } else {
                  customSnackBar("select_any_payment_method".tr, type: ToasterMessageType.info);
                }
              },
              child: Text('Proceed to Payment'),
            ),
          ],
        ),
      ),
    );
  }

  // Helper to get the selected payment method name for display
  String _getSelectedPaymentMethodName() {
    switch (checkoutController.selectedPaymentMethod) {
      case PaymentMethodName.digitalPayment:
        return "Digital Payment";
      case PaymentMethodName.cos:
        return "Cash on Service";
      case PaymentMethodName.walletMoney:
        return "Wallet Money";
      case PaymentMethodName.offline:
        return "Offline Payment";
      case PaymentMethodName.none:
      default:
        return "Not Selected";
    }
  }

  // Build payment method list
  Widget _buildPaymentMethodList() {
    return Obx(() {
      switch (checkoutController.selectedPaymentMethod) {
        case PaymentMethodName.digitalPayment:
          return _buildDigitalPaymentMethodList();
        default:
          return SizedBox.shrink();
      }
    });
  }

  // Build digital payment methods list
  Widget _buildDigitalPaymentMethodList() {
    return ListView.builder(
      itemCount: checkoutController.digitalPaymentList.length,
      shrinkWrap: true,
      itemBuilder: (context, index) {
        var paymentMethod = checkoutController.digitalPaymentList[index];
        return ListTile(
          title: Text("Select Payment Method"),
          onTap: () {
            checkoutController.selectedPaymentMethod = PaymentMethodName.digitalPayment;
            checkoutController.selectedPaymentMethod = paymentMethod as PaymentMethodName;
            checkoutController.update();
          },
          tileColor: checkoutController.selectedDigitalPaymentMethod == paymentMethod
              ? Colors.blueAccent
              : null,
        );
      },
    );
  }

  // Proceed with the payment after selecting a payment method
  void _proceedWithPayment() {
    if (checkoutController.selectedPaymentMethod == PaymentMethodName.digitalPayment) {
      DigitalPaymentMethod? selectedDigitalPayment = checkoutController.selectedDigitalPaymentMethod;
      if (selectedDigitalPayment != null) {
        customSnackBar("Payment is being processed for ${selectedDigitalPayment.gateway}",
            type: ToasterMessageType.success);
      }
    } else if (checkoutController.selectedPaymentMethod == PaymentMethodName.offline) {
      OfflinePaymentModel? selectedOfflinePayment = checkoutController.selectedOfflineMethod;
      if (selectedOfflinePayment != null) {
        customSnackBar("Offline payment method selected for ${selectedOfflinePayment.name}",
            type: ToasterMessageType.success);
      }
    } else {
      customSnackBar("Invalid payment method selected", type: ToasterMessageType.error);
    }
  }
}
