import 'package:flutter/material.dart';

class PaymentGatewaysPage extends StatelessWidget {
  final String bookingId;
  final String customerId;
  final double amount;

  // Constructor to receive data from the previous screen
  const PaymentGatewaysPage({
    super.key,
    required this.bookingId,
    required this.customerId,
    required this.amount,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select Payment Method'),
      ),
      body: Center(
        child: Column(
          children: [
            // Display booking and customer details
            Text('Booking ID: $bookingId'),
            Text('Customer ID: $customerId'),
            Text('Amount: \$${amount.toStringAsFixed(2)}'),

            // Add your payment gateway options here
            ElevatedButton(
              onPressed: () {
                // Handle card payment processing
                _processCardPayment();
              },
              child: Text("Pay with Card"),
            ),
            ElevatedButton(
              onPressed: () {
                // Handle PayPal or other payment gateways
                _processPaypalPayment();
              },
              child: Text("Pay with PayPal"),
            ),
          ],
        ),
      ),
    );
  }

  // Example payment processing method for card payment
  void _processCardPayment() {
    print("Processing Card Payment...");
    print("Booking ID: $bookingId");
    print("Customer ID: $customerId");
    print("Amount: \$${amount.toStringAsFixed(2)}");
  }

  // Example PayPal payment processing
  void _processPaypalPayment() {
    print("Processing PayPal Payment...");
    print("Booking ID: $bookingId");
    print("Customer ID: $customerId");
    print("Amount: \$${amount.toStringAsFixed(2)}");
  }
}
