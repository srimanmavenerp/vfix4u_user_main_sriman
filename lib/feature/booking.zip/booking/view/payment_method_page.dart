import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:demandium/utils/core_export.dart'; // You may need to adjust this import


class PaymentGatewaysPage extends StatelessWidget {
  const PaymentGatewaysPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select Payment Method'),
      ),
      body: Center(
        child: Column(
          children: [
            // Add your payment gateway options here
            ElevatedButton(
              onPressed: () {
                // Navigate to the payment gateway processing page
                _processCardPayment();
              },
              child: Text("Pay with Card"),
            ),
            ElevatedButton(
              onPressed: () {
                // Handle PayPal or other gateway
                _processPaypalPayment();
              },
              child: Text("Pay with PayPal"),
            ),
            // Add more payment methods as required
          ],
        ),
      ),
    );
  }

  // Example payment processing method
  void _processCardPayment() {
    // Logic to handle card payment
    print("Processing Card Payment...");
  }

  // Example PayPal payment processing
  void _processPaypalPayment() {
    // Logic to handle PayPal payment
    print("Processing PayPal Payment...");
  }
}
